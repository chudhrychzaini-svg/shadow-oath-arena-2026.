## Packages
framer-motion | Essential for smooth character animations and combat effects
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes efficiently

## Notes
- Game logic will use a requestAnimationFrame loop in the Fight component
- Visuals rely on CSS/Framer Motion rather than Canvas for this MVP to leverage React state easily
- Audio is simulated via visual cues (screen shake, flashes) as no audio assets are provided
- "Sprites" are procedurally generated using CSS gradients and SVG filters
