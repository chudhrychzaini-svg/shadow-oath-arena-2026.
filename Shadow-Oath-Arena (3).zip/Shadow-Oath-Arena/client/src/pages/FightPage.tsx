import { useEffect, useRef, useState, useMemo } from "react";
import { useLocation, useSearch } from "wouter";
import { useFighter, useCreateMatch } from "@/hooks/use-api";
import { GameHUD } from "@/components/GameHUD";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2 } from "lucide-react";

// --- Game Constants ---
const FPS = 60;
const GRAVITY = 0.8;
const MOVE_SPEED = 5;
const JUMP_FORCE = -15;
const GROUND_Y = 400; // Pixels from top
const HITBOX_WIDTH = 60;
const HITBOX_HEIGHT = 120;
const STAGE_WIDTH = 1000;

// --- Types ---
type Action = 'IDLE' | 'RUN' | 'JUMP' | 'ATTACK_LIGHT' | 'ATTACK_HEAVY' | 'BLOCK' | 'HIT' | 'DEAD';

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  health: number;
  maxHealth: number;
  energy: number;
  isAwakened: boolean;
  action: Action;
  facingRight: boolean;
  width: number;
  height: number;
  frame: number; // For animation timing
}

// --- Helper: AABB Collision ---
function checkCollision(p1: Player, p2: Player) {
  return (
    p1.x < p2.x + p2.width &&
    p1.x + p1.width > p2.x &&
    p1.y < p2.y + p2.height &&
    p1.y + p1.height > p2.y
  );
}

export default function FightPage() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const fighterId = Number(params.get("fighter"));
  // Opponent is hardcoded to be random or same for MVP, let's say ID 2 or ID 1 if same
  const opponentId = fighterId === 1 ? 2 : 1; 
  
  const { data: p1Data, isLoading: l1 } = useFighter(fighterId);
  const { data: p2Data, isLoading: l2 } = useFighter(opponentId);
  const createMatch = useCreateMatch();
  const [, setLocation] = useLocation();

  const [gameState, setGameState] = useState<'READY' | 'FIGHT' | 'OVER'>('READY');
  const [winner, setWinner] = useState<number | null>(null);
  const [timer, setTimer] = useState(99);
  const [combo, setCombo] = useState({ count: 0, active: false });

  // Refs for game loop state (to avoid re-renders on every frame)
  const p1Ref = useRef<Player>({
    x: 200, y: GROUND_Y, vx: 0, vy: 0, health: 100, maxHealth: 100, energy: 0,
    isAwakened: false, action: 'IDLE', facingRight: true, width: HITBOX_WIDTH, height: HITBOX_HEIGHT, frame: 0
  });
  
  const p2Ref = useRef<Player>({
    x: STAGE_WIDTH - 200, y: GROUND_Y, vx: 0, vy: 0, health: 100, maxHealth: 100, energy: 0,
    isAwakened: false, action: 'IDLE', facingRight: false, width: HITBOX_WIDTH, height: HITBOX_HEIGHT, frame: 0
  });

  const keysRef = useRef<Set<string>>(new Set());
  const loopRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  const dialogueRef = useRef<string | null>(null);

  // Sync refs to React state for rendering HUD only
  const [hudState, setHudState] = useState({
    p1: p1Ref.current,
    p2: p2Ref.current,
    timer: 99
  });

  // --- Input Handling ---
  useEffect(() => {
    const down = (e: KeyboardEvent) => keysRef.current.add(e.code);
    const up = (e: KeyboardEvent) => keysRef.current.delete(e.code);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
    };
  }, []);

  // --- Game Loop ---
  useEffect(() => {
    if (!p1Data || !p2Data || gameState === 'OVER') return;

    // Initialize stats from data
    if (gameState === 'READY') {
      p1Ref.current.maxHealth = p1Data.stats.health * 10;
      p1Ref.current.health = p1Ref.current.maxHealth;
      p2Ref.current.maxHealth = p2Data.stats.health * 10;
      p2Ref.current.health = p2Ref.current.maxHealth;
      
      // Start Countdown
      setTimeout(() => setGameState('FIGHT'), 3000);
    }

    const update = (time: number) => {
      if (gameState !== 'FIGHT') {
        loopRef.current = requestAnimationFrame(update);
        return;
      }

      const delta = time - lastTimeRef.current;
      if (delta < 1000 / FPS) {
        loopRef.current = requestAnimationFrame(update);
        return;
      }
      lastTimeRef.current = time;

      const p1 = p1Ref.current;
      const p2 = p2Ref.current;
      const keys = keysRef.current;

      // --- P1 CONTROLS ---
      if (p1.action !== 'HIT' && p1.action !== 'DEAD') {
        // Reset X velocity (friction)
        p1.vx = 0;

        if (keys.has('ArrowLeft')) { p1.vx = -MOVE_SPEED; p1.facingRight = false; }
        if (keys.has('ArrowRight')) { p1.vx = MOVE_SPEED; p1.facingRight = true; }
        
        // Jump
        if (keys.has('ArrowUp') && p1.y >= GROUND_Y) { p1.vy = JUMP_FORCE; p1.action = 'JUMP'; }
        
        // Attacks
        if (keys.has('KeyZ') && p1.action !== 'ATTACK_LIGHT') { 
          p1.action = 'ATTACK_LIGHT'; 
          p1.frame = 20; // Attack duration frames
        }
        if (keys.has('KeyX') && p1.action !== 'ATTACK_HEAVY') { 
          p1.action = 'ATTACK_HEAVY';
          p1.frame = 30;
        }
        if (keys.has('KeyC')) { p1.action = 'BLOCK'; }
        if (keys.has('Space') && p1.energy >= 100) { p1.isAwakened = true; p1.energy = 0; }

        // Idle state if nothing else
        if (p1.y >= GROUND_Y && p1.vx === 0 && p1.action !== 'BLOCK' && p1.frame <= 0) {
          p1.action = 'IDLE';
        }
        if (p1.vx !== 0 && p1.y >= GROUND_Y && p1.frame <= 0) {
          p1.action = 'RUN';
        }
      }

      // --- P2 AI (Simple) ---
      if (p2.action !== 'HIT' && p2.action !== 'DEAD') {
         const dist = Math.abs(p1.x - p2.x);
         p2.vx = 0;
         
         // Face player
         p2.facingRight = p1.x > p2.x;

         // Logic
         if (dist > 100) {
             // Chase
             p2.vx = p1.x > p2.x ? MOVE_SPEED * 0.8 : -MOVE_SPEED * 0.8;
             p2.action = 'RUN';
         } else {
             // Attack chance
             if (Math.random() < 0.02 && p2.frame <= 0) {
                 p2.action = 'ATTACK_LIGHT';
                 p2.frame = 20;
             } else if (p2.frame <= 0) {
                 p2.action = 'IDLE';
             }
         }
      }

      // --- PHYSICS & LOGIC ---
      [p1, p2].forEach(p => {
        // Gravity
        p.vy += GRAVITY;
        p.y += p.vy;
        p.x += p.vx;

        // Ground collision
        if (p.y > GROUND_Y) {
          p.y = GROUND_Y;
          p.vy = 0;
        }

        // Walls
        if (p.x < 0) p.x = 0;
        if (p.x > STAGE_WIDTH - p.width) p.x = STAGE_WIDTH - p.width;

        // Action Frames Countdown
        if (p.frame > 0) p.frame--;
        if (p.frame <= 0 && (p.action === 'ATTACK_LIGHT' || p.action === 'ATTACK_HEAVY' || p.action === 'HIT')) {
          p.action = 'IDLE';
        }
      });

      // --- HIT DETECTION ---
      // Check P1 hitting P2
      if ((p1.action === 'ATTACK_LIGHT' || p1.action === 'ATTACK_HEAVY') && p1.frame > 10 && p1.frame < 18) {
         // Simple range check based on facing
         const hitRange = p1.facingRight ? p1.x + p1.width + 50 : p1.x - 50;
         const hit = p1.facingRight ? (hitRange > p2.x) : (hitRange < p2.x + p2.width);
         
         if (hit && Math.abs(p1.y - p2.y) < 50 && p2.action !== 'HIT' && p2.action !== 'DEAD') {
             // Hit confirmed
             const damage = p1.action === 'ATTACK_HEAVY' ? 15 : 8;
             p2.health -= damage;
             p2.action = 'HIT';
             p2.frame = 15; // Stun time
             p2.vx = p1.facingRight ? 10 : -10; // Knockback
             p2.vy = -5;
             
             // Rage gain
             p1.energy = Math.min(100, p1.energy + 10);
             p2.energy = Math.min(100, p2.energy + 5);

             setCombo(c => ({ count: c.count + 1, active: true }));
             setTimeout(() => setCombo(c => ({ ...c, active: false })), 2000); // Reset timer logic would be better but this is MVP
         }
      }
      
      // Check P2 hitting P1 (AI)
       if ((p2.action === 'ATTACK_LIGHT' || p2.action === 'ATTACK_HEAVY') && p2.frame > 10 && p2.frame < 18) {
         const hitRange = p2.facingRight ? p2.x + p2.width + 50 : p2.x - 50;
         const hit = p2.facingRight ? (hitRange > p1.x) : (hitRange < p1.x + p1.width);
         
         if (hit && Math.abs(p2.y - p1.y) < 50 && p1.action !== 'HIT' && p1.action !== 'DEAD') {
             const damage = 8; // AI weak for now
             p1.health -= damage;
             p1.action = 'HIT';
             p1.frame = 15;
             p1.vx = p2.facingRight ? 10 : -10;
             p1.vy = -5;
         }
      }

      // --- WIN CONDITION ---
      if (p1.health <= 0 || p2.health <= 0) {
        setGameState('OVER');
        const winnerId = p1.health > 0 ? fighterId : opponentId;
        setWinner(winnerId);
        
        // Record match
        createMatch.mutate({
            fighter1Id: fighterId,
            fighter2Id: opponentId,
            winnerId: winnerId,
            arenaId: 1, // Default for now
            durationSeconds: 99 - timer,
            finishedWithAwakening: p1.isAwakened || p2.isAwakened,
            timestamp: new Date().toISOString()
        });
      }

      setHudState({ p1: {...p1}, p2: {...p2}, timer });
      loopRef.current = requestAnimationFrame(update);
    };

    loopRef.current = requestAnimationFrame(update);
    
    // Timer Tick
    const timerInterval = setInterval(() => {
        if (gameState === 'FIGHT') setTimer(t => Math.max(0, t - 1));
    }, 1000);

    return () => {
      if (loopRef.current) cancelAnimationFrame(loopRef.current);
      clearInterval(timerInterval);
    };
  }, [p1Data, p2Data, gameState, timer]);

  if (l1 || l2 || !p1Data || !p2Data) return <div className="h-screen bg-black flex items-center justify-center"><Loader2 className="animate-spin text-primary w-12 h-12"/></div>;

  return (
    <div className="h-screen w-screen bg-black overflow-hidden relative select-none">
      {/* HUD */}
      <GameHUD p1={hudState.p1} p2={hudState.p2} p1Fighter={p1Data} p2Fighter={p2Data} timer={hudState.timer} combo={combo} />

      {/* Arena Background */}
      <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-slate-900 opacity-80" />
          {/* Grid Floor */}
          <div className="absolute bottom-0 h-1/3 w-full bg-[linear-gradient(transparent_0%,_rgba(50,50,50,0.5)_1px,_transparent_1px)] bg-[length:50px_50px] [transform:perspective(500px)_rotateX(60deg)] origin-bottom" />
      </div>

      {/* Game Stage */}
      <div className="absolute inset-0 z-10">
        
        {/* PLAYER 1 */}
        <motion.div
            style={{ 
                x: hudState.p1.x, 
                y: hudState.p1.y,
                width: hudState.p1.width,
                height: hudState.p1.height,
            }}
            className="absolute bg-transparent"
        >
            {/* Visual Representation (Rectangle + Glow) */}
            <div className={cn(
                "w-full h-full relative transition-transform duration-100",
                !hudState.p1.facingRight && "scale-x-[-1]"
            )}>
                <div className={cn(
                    "absolute inset-0 rounded-sm shadow-[0_0_30px_currentColor] opacity-80",
                    hudState.p1.isAwakened ? "bg-cyan-500 text-cyan-500" : "bg-red-600 text-red-600",
                    hudState.p1.action === 'ATTACK_LIGHT' && "translate-x-10",
                    hudState.p1.action === 'HIT' && "opacity-50 blur-sm"
                )} />
                {/* Eye/Head */}
                <div className="absolute top-2 right-2 w-4 h-2 bg-white shadow-[0_0_10px_white]" />
            </div>
        </motion.div>

        {/* PLAYER 2 */}
        <motion.div
            style={{ 
                x: hudState.p2.x, 
                y: hudState.p2.y,
                width: hudState.p2.width,
                height: hudState.p2.height,
            }}
            className="absolute bg-transparent"
        >
             <div className={cn(
                "w-full h-full relative transition-transform duration-100",
                !hudState.p2.facingRight && "scale-x-[-1]"
            )}>
                <div className={cn(
                    "absolute inset-0 rounded-sm shadow-[0_0_30px_currentColor] opacity-80 bg-purple-600 text-purple-600",
                    hudState.p2.action === 'ATTACK_LIGHT' && "translate-x-10",
                    hudState.p2.action === 'HIT' && "opacity-50 blur-sm"
                )} />
                <div className="absolute top-2 right-2 w-4 h-2 bg-white shadow-[0_0_10px_white]" />
            </div>
        </motion.div>
      </div>

      {/* Overlays */}
      <AnimatePresence>
        {gameState === 'READY' && (
            <motion.div 
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1.5, opacity: 1 }}
                exit={{ scale: 3, opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center z-50 pointer-events-none"
            >
                <h1 className="text-9xl font-black text-white italic drop-shadow-[0_0_50px_rgba(255,255,255,0.8)]">READY?</h1>
            </motion.div>
        )}

        {gameState === 'OVER' && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/80 z-50 flex flex-col items-center justify-center space-y-8"
            >
                <h1 className="text-8xl font-black text-primary uppercase tracking-tighter">
                    {winner === fighterId ? "VICTORY" : "DEFEAT"}
                </h1>
                <div className="flex gap-4">
                    <button onClick={() => window.location.reload()} className="px-8 py-3 bg-white text-black font-display font-bold uppercase hover:bg-gray-200">
                        Rematch
                    </button>
                    <button onClick={() => setLocation('/')} className="px-8 py-3 border border-white text-white font-display font-bold uppercase hover:bg-white/10">
                        Menu
                    </button>
                </div>
            </motion.div>
        )}
      </AnimatePresence>

      {/* Controls Hint */}
      <div className="absolute bottom-4 left-4 text-white/30 text-xs font-mono">
          ARROWS: Move | Z: Light | X: Heavy | C: Block | SPACE: Awaken
      </div>
    </div>
  );
}
