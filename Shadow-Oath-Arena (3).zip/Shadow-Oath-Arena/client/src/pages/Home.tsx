import { Link } from "wouter";
import { motion } from "framer-motion";
import { useMatchHistory } from "@/hooks/use-api";
import { Sword, Skull, ScrollText } from "lucide-react";

export default function Home() {
  const { data: history } = useMatchHistory();

  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-black to-black opacity-80" />
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/black-scales.png')] opacity-20" />
      
      {/* Cinematic Fog */}
      <motion.div 
        animate={{ x: [-100, 100], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear", repeatType: "mirror" }}
        className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/5 to-transparent blur-3xl"
      />

      <div className="relative z-10 max-w-4xl w-full text-center space-y-12 px-4">
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <h1 className="text-7xl md:text-9xl font-display font-black text-white tracking-tighter uppercase drop-shadow-[0_0_25px_rgba(220,38,38,0.8)]">
            Fatal <span className="text-primary">Oath</span>
          </h1>
          <p className="mt-4 text-xl text-white/60 font-hud tracking-[0.3em] uppercase">
            Redemption is earned in blood
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
          <Link href="/select" className="group">
            <div className="h-full bg-white/5 border border-white/10 p-8 rounded-lg hover:bg-primary/20 hover:border-primary hover:scale-105 transition-all duration-300 cursor-pointer flex flex-col items-center gap-4 backdrop-blur-sm">
              <Sword className="w-12 h-12 text-white/80 group-hover:text-primary transition-colors" />
              <span className="text-2xl font-bold font-display uppercase tracking-wider text-white">Fight</span>
            </div>
          </Link>
          
          <Link href="/lore" className="group">
            <div className="h-full bg-white/5 border border-white/10 p-8 rounded-lg hover:bg-purple-900/20 hover:border-purple-500 hover:scale-105 transition-all duration-300 cursor-pointer flex flex-col items-center gap-4 backdrop-blur-sm">
              <ScrollText className="w-12 h-12 text-white/80 group-hover:text-purple-400 transition-colors" />
              <span className="text-2xl font-bold font-display uppercase tracking-wider text-white">Lore</span>
            </div>
          </Link>

          <div className="bg-white/5 border border-white/10 p-8 rounded-lg opacity-50 cursor-not-allowed flex flex-col items-center gap-4 backdrop-blur-sm">
            <Skull className="w-12 h-12 text-white/40" />
            <span className="text-2xl font-bold font-display uppercase tracking-wider text-white/40">Online</span>
            <span className="text-xs font-hud text-primary uppercase">Coming Soon</span>
          </div>
        </div>

        {/* Recent Matches */}
        <div className="mt-12 pt-12 border-t border-white/10">
          <h2 className="text-white/40 font-hud uppercase tracking-widest text-sm mb-4">Recent Battles</h2>
          <div className="flex justify-center gap-2 overflow-x-auto pb-4">
            {history?.slice(0, 5).map((match, i) => (
              <div key={match.id} className="bg-black/40 border border-white/5 px-4 py-2 rounded text-xs font-mono text-white/60 whitespace-nowrap">
                Match #{match.id} • {match.finishedWithAwakening ? "AWAKENING FINISH" : "DECISION"}
              </div>
            ))}
            {(!history || history.length === 0) && (
              <span className="text-white/20 italic text-sm">No blood spilled yet...</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
