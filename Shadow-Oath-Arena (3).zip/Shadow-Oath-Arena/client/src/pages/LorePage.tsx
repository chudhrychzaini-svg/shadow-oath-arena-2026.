import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function LorePage() {
  const loreEntries = [
    {
      title: "The Great Fracture",
      content: "Three centuries ago, the world didn't end with a bang, but a scream. The dimensional barriers thinned, allowing the 'Shadow' to seep into our reality. Those who survived the initial madness found themselves changed, capable of channeling energy that shouldn't exist."
    },
    {
      title: "The Oaths",
      content: "To control the chaos, the surviving warlords established the Oaths. A fighter is nothing without their word. To break an oath is to lose one's humanity and succumb fully to the Shadow. We fight not just for territory, but to prove our souls are still our own."
    },
    {
      title: "Awakening",
      content: "Push a warrior to the brink of death, and you may witness a miracle or a monstrosity. Awakening is the moment the soul resonates perfectly with the Shadow energy. It is power incarnate, but it burns the life force of the user. Use it wisely, or burn out."
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white p-6 md:p-12 relative overflow-y-auto">
      <div className="max-w-3xl mx-auto">
        <header className="mb-12 flex items-center gap-4">
          <Link href="/">
             <div className="p-2 bg-white/5 rounded-full hover:bg-white/10 cursor-pointer transition-colors">
                 <ArrowLeft className="w-6 h-6" />
             </div>
          </Link>
          <h1 className="text-4xl font-display font-bold uppercase tracking-widest text-primary">Archives</h1>
        </header>

        <div className="space-y-12">
          {loreEntries.map((entry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="border-l-2 border-primary/30 pl-8 py-2 relative"
            >
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary" />
              <h2 className="text-2xl font-display font-bold mb-4 text-white/90">{entry.title}</h2>
              <p className="text-lg text-white/60 leading-relaxed font-serif italic">
                "{entry.content}"
              </p>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-24 text-center">
            <p className="text-white/20 text-sm font-hud">END OF RECORD</p>
        </div>
      </div>
    </div>
  );
}
