import { useState } from "react";
import { useLocation } from "wouter";
import { useFighters, useArenas } from "@/hooks/use-api";
import { FighterCard } from "@/components/FighterCard";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import type { Fighter, Arena } from "@shared/schema";

export default function SelectScreen() {
  const [step, setStep] = useState<'fighter' | 'arena'>('fighter');
  const [selectedFighter, setSelectedFighter] = useState<Fighter | null>(null);
  const [selectedArena, setSelectedArena] = useState<Arena | null>(null);
  const [, setLocation] = useLocation();

  const { data: fighters, isLoading: loadingFighters } = useFighters();
  const { data: arenas, isLoading: loadingArenas } = useArenas();

  const handleStart = () => {
    if (selectedFighter && selectedArena) {
      // Pass data via URL params mostly for MVP, better with context but this works
      setLocation(`/fight?fighter=${selectedFighter.id}&arena=${selectedArena.id}`);
    }
  };

  if (loadingFighters || loadingArenas) {
    return (
      <div className="h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6 md:p-12 relative overflow-hidden flex flex-col">
       {/* Background */}
       <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-black to-black -z-10" />

      {/* Header */}
      <header className="mb-8 flex justify-between items-center z-10">
        <div>
          <h1 className="text-4xl font-display font-bold uppercase tracking-widest text-shadow-glow">
            {step === 'fighter' ? 'Choose Your Warrior' : 'Select Battleground'}
          </h1>
          <p className="text-white/50 font-hud mt-2">
            {step === 'fighter' ? 'Every soul carries a burden.' : 'Where will history be written?'}
          </p>
        </div>
        <div className="flex gap-2">
          {step === 'arena' && (
             <Button variant="outline" onClick={() => setStep('fighter')} className="font-hud uppercase border-white/20 text-white hover:bg-white/10">
               Back
             </Button>
          )}
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 relative z-10">
        <AnimatePresence mode="wait">
          {step === 'fighter' ? (
            <motion.div 
              key="fighters"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {fighters?.map((fighter) => (
                <FighterCard 
                  key={fighter.id} 
                  fighter={fighter} 
                  isSelected={selectedFighter?.id === fighter.id}
                  onClick={() => setSelectedFighter(fighter)}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div 
              key="arenas"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
            >
              {arenas?.map((arena) => (
                <div 
                  key={arena.id}
                  onClick={() => setSelectedArena(arena)}
                  className={`
                    cursor-pointer group relative h-64 rounded-xl overflow-hidden border-2 transition-all duration-300
                    ${selectedArena?.id === arena.id ? 'border-primary shadow-[0_0_30px_rgba(220,38,38,0.4)]' : 'border-white/10 hover:border-white/40'}
                  `}
                >
                  {/* Dynamic background approximation since no real URLs */}
                  <div className={`absolute inset-0 bg-gradient-to-br opacity-60 transition-opacity group-hover:opacity-80
                    ${arena.hazard?.includes('Rain') ? 'from-blue-900 to-slate-900' : 
                      arena.hazard?.includes('Fire') ? 'from-red-900 to-orange-900' : 'from-gray-800 to-black'}
                  `} />
                  
                  <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-black via-black/80 to-transparent">
                    <h3 className="text-2xl font-display font-bold uppercase text-white">{arena.name}</h3>
                    <p className="text-white/60 text-sm font-hud mt-1 uppercase tracking-wider">{arena.hazard || 'Standard Conditions'}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer / Actions */}
      <div className="mt-8 flex justify-end items-center h-20 border-t border-white/10 pt-4 z-10">
        {step === 'fighter' && selectedFighter && (
          <Button 
            onClick={() => setStep('arena')}
            className="bg-primary hover:bg-red-600 text-white font-display text-xl px-8 py-6 uppercase tracking-widest shadow-lg shadow-red-900/20 hover:shadow-red-900/50 transition-all"
          >
            Next <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        )}
        
        {step === 'arena' && selectedArena && (
          <Button 
            onClick={handleStart}
            className="bg-white text-black hover:bg-gray-200 font-display text-xl px-12 py-6 uppercase tracking-widest shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.5)] transition-all"
          >
            Fight!
          </Button>
        )}
      </div>
    </div>
  );
}
