import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type MatchInput } from "@shared/routes";

// Fighters
export function useFighters() {
  return useQuery({
    queryKey: [api.fighters.list.path],
    queryFn: async () => {
      const res = await fetch(api.fighters.list.path);
      if (!res.ok) throw new Error("Failed to fetch fighters");
      return api.fighters.list.responses[200].parse(await res.json());
    },
  });
}

export function useFighter(id: number | null) {
  return useQuery({
    queryKey: [api.fighters.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      const res = await fetch(api.fighters.get.path.replace(":id", String(id)));
      if (!res.ok) throw new Error("Failed to fetch fighter");
      return api.fighters.get.responses[200].parse(await res.json());
    },
  });
}

// Arenas
export function useArenas() {
  return useQuery({
    queryKey: [api.arenas.list.path],
    queryFn: async () => {
      const res = await fetch(api.arenas.list.path);
      if (!res.ok) throw new Error("Failed to fetch arenas");
      return api.arenas.list.responses[200].parse(await res.json());
    },
  });
}

// Matches
export function useCreateMatch() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: MatchInput) => {
      const res = await fetch(api.matches.create.path, {
        method: api.matches.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.matches.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to record match");
      }
      return api.matches.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.matches.history.path] });
    },
  });
}

export function useMatchHistory() {
  return useQuery({
    queryKey: [api.matches.history.path],
    queryFn: async () => {
      const res = await fetch(api.matches.history.path);
      if (!res.ok) throw new Error("Failed to fetch match history");
      return api.matches.history.responses[200].parse(await res.json());
    },
  });
}
