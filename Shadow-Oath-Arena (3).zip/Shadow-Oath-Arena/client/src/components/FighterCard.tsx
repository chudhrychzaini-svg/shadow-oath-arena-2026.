import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Fighter } from "@shared/schema";

interface FighterCardProps {
  fighter: Fighter;
  isSelected?: boolean;
  onClick?: () => void;
  disabled?: boolean;
}

export function FighterCard({ fighter, isSelected, onClick, disabled }: FighterCardProps) {
  // Determine gradient based on style/element
  const getGradient = (style: string) => {
    if (style.includes("Fire")) return "from-red-600 to-orange-500";
    if (style.includes("Shadow")) return "from-purple-900 to-black";
    if (style.includes("Time")) return "from-blue-600 to-cyan-400";
    if (style.includes("Beast")) return "from-green-700 to-emerald-900";
    return "from-slate-700 to-slate-900";
  };

  return (
    <motion.button
      whileHover={!disabled ? { scale: 1.05, y: -5 } : {}}
      whileTap={!disabled ? { scale: 0.95 } : {}}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "relative w-full h-80 rounded-xl overflow-hidden border-2 transition-all duration-300 group text-left flex flex-col justify-end p-6",
        isSelected 
          ? "border-primary shadow-[0_0_30px_rgba(220,38,38,0.5)] ring-2 ring-primary/50" 
          : "border-white/10 hover:border-white/30",
        disabled && "opacity-50 grayscale cursor-not-allowed"
      )}
    >
      {/* Background with dynamic gradient */}
      <div className={cn(
        "absolute inset-0 bg-gradient-to-br opacity-80 group-hover:opacity-100 transition-opacity",
        getGradient(fighter.style)
      )} />
      
      {/* Texture overlay */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-30 mix-blend-overlay" />
      
      {/* Character Silhouette/Avatar placeholder */}
      <div className="absolute inset-0 flex items-center justify-center opacity-40 group-hover:opacity-60 transition-all duration-500 transform group-hover:scale-110">
        <span className="text-9xl font-display font-bold text-white/10 select-none">
          {fighter.name.charAt(0)}
        </span>
      </div>

      {/* Info Content */}
      <div className="relative z-10 space-y-2">
        <div className="flex justify-between items-end border-b border-white/20 pb-2 mb-2">
          <h3 className="text-3xl font-display font-black text-white uppercase tracking-wider drop-shadow-md">
            {fighter.name}
          </h3>
          <span className="font-hud text-xs text-white/60 tracking-widest uppercase">
            {fighter.style}
          </span>
        </div>

        <p className="text-sm text-white/80 line-clamp-2 font-medium">
          {fighter.lore}
        </p>

        {/* Mini Stats Graph */}
        <div className="flex gap-1 pt-2">
          {Object.entries(fighter.stats).map(([stat, value]) => (
            <div key={stat} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full h-16 bg-black/40 rounded-sm relative overflow-hidden flex items-end">
                <motion.div 
                  initial={{ height: 0 }}
                  animate={{ height: `${(value / 10) * 100}%` }}
                  className={cn(
                    "w-full opacity-80",
                    stat === 'power' ? 'bg-red-500' : 
                    stat === 'speed' ? 'bg-blue-500' :
                    stat === 'defense' ? 'bg-green-500' : 'bg-yellow-500'
                  )}
                />
              </div>
              <span className="text-[9px] uppercase text-white/50 font-hud">{stat.substring(0, 3)}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.button>
  );
}
