import { motion, AnimatePresence } from "framer-motion";
import type { Fighter } from "@shared/schema";
import { cn } from "@/lib/utils";

interface PlayerState {
  health: number;
  maxHealth: number;
  energy: number; // 0-100 Rage
  isAwakened: boolean;
}

interface GameHUDProps {
  p1: PlayerState;
  p2: PlayerState;
  p1Fighter: Fighter;
  p2Fighter: Fighter;
  timer: number;
  combo?: { count: number; active: boolean };
}

function HealthBar({ current, max, isLeft, isAwakened }: { current: number; max: number; isLeft: boolean; isAwakened: boolean }) {
  const percentage = Math.max(0, (current / max) * 100);
  
  return (
    <div className={cn("w-full h-8 bg-black/60 relative border border-white/10 transform skew-x-[-15deg]", isLeft ? "origin-left" : "origin-right")}>
      {/* Background damage bleed */}
      <motion.div 
        className="absolute top-0 bottom-0 bg-red-900 transition-all duration-1000 ease-out"
        style={{ 
          left: isLeft ? 0 : 'auto', 
          right: isLeft ? 'auto' : 0, 
          width: `${percentage}%` 
        }}
      />
      {/* Actual Health */}
      <motion.div 
        className={cn(
          "absolute top-0 bottom-0 transition-all duration-200 ease-linear shadow-[0_0_10px_currentColor]",
          isAwakened ? "bg-cyan-400 text-cyan-400" : percentage < 30 ? "bg-red-600 text-red-600" : "bg-yellow-400 text-yellow-400"
        )}
        style={{ 
          left: isLeft ? 0 : 'auto', 
          right: isLeft ? 'auto' : 0, 
          width: `${percentage}%` 
        }}
      />
    </div>
  );
}

function EnergyBar({ current, isLeft }: { current: number; isLeft: boolean }) {
  return (
    <div className={cn("w-3/4 h-3 mt-2 bg-black/60 relative border border-white/10 skew-x-[-15deg]", isLeft ? "mr-auto" : "ml-auto")}>
      <motion.div 
        className={cn(
          "absolute inset-y-0 transition-all duration-100 bg-blue-500 shadow-[0_0_8px_blue]",
          current >= 100 && "bg-white animate-pulse shadow-[0_0_15px_white]"
        )}
        style={{ 
          left: isLeft ? 0 : 'auto', 
          right: isLeft ? 'auto' : 0, 
          width: `${current}%` 
        }}
      />
    </div>
  );
}

export function GameHUD({ p1, p2, p1Fighter, p2Fighter, timer, combo }: GameHUDProps) {
  return (
    <div className="absolute inset-x-0 top-0 p-8 z-50 pointer-events-none font-hud select-none">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-8 items-start">
        
        {/* P1 Stats */}
        <div className="flex flex-col">
          <div className="flex justify-between items-end mb-1 px-2">
            <span className="text-2xl font-bold tracking-widest uppercase text-white drop-shadow-md">{p1Fighter.name}</span>
            {p1.isAwakened && <span className="text-cyan-400 animate-pulse font-bold text-sm tracking-[0.2em]">AWAKENED</span>}
          </div>
          <HealthBar current={p1.health} max={p1.maxHealth} isLeft={true} isAwakened={p1.isAwakened} />
          <EnergyBar current={p1.energy} isLeft={true} />
        </div>

        {/* Timer */}
        <div className="relative flex justify-center">
          <div className="bg-gradient-to-b from-slate-800 to-black border-2 border-white/20 w-20 h-20 flex items-center justify-center rounded-lg shadow-xl relative z-10 transform rotate-45">
            <span className={cn(
              "text-4xl font-black transform -rotate-45",
              timer <= 10 ? "text-red-500 animate-pulse" : "text-white"
            )}>
              {timer}
            </span>
          </div>
        </div>

        {/* P2 Stats */}
        <div className="flex flex-col">
          <div className="flex justify-between items-end mb-1 px-2 flex-row-reverse">
            <span className="text-2xl font-bold tracking-widest uppercase text-white drop-shadow-md">{p2Fighter.name}</span>
            {p2.isAwakened && <span className="text-cyan-400 animate-pulse font-bold text-sm tracking-[0.2em]">AWAKENED</span>}
          </div>
          <HealthBar current={p2.health} max={p2.maxHealth} isLeft={false} isAwakened={p2.isAwakened} />
          <EnergyBar current={p2.energy} isLeft={false} />
        </div>
      </div>

      {/* Combo Counter */}
      <AnimatePresence>
        {combo && combo.count > 1 && (
          <motion.div
            initial={{ scale: 0.5, opacity: 0, y: 50 }}
            animate={{ scale: 1.2, opacity: 1, y: 0 }}
            exit={{ scale: 2, opacity: 0 }}
            className="absolute top-32 left-10 text-left"
          >
            <span className="block text-6xl font-black italic text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-red-600 drop-shadow-[0_4px_0_rgba(0,0,0,1)]">
              {combo.count} HITS
            </span>
            <span className="block text-xl text-white font-bold tracking-[0.5em] uppercase pl-1">
              {combo.count > 5 ? "BRUTAL!" : "COMBO"}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
