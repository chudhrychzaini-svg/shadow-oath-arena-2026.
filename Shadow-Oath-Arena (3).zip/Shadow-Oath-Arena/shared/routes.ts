import { z } from 'zod';
import { insertMatchSchema, fighters, arenas, matches } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  fighters: {
    list: {
      method: 'GET' as const,
      path: '/api/fighters',
      responses: {
        200: z.array(z.custom<typeof fighters.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/fighters/:id',
      responses: {
        200: z.custom<typeof fighters.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  arenas: {
    list: {
      method: 'GET' as const,
      path: '/api/arenas',
      responses: {
        200: z.array(z.custom<typeof arenas.$inferSelect>()),
      },
    },
  },
  matches: {
    create: {
      method: 'POST' as const,
      path: '/api/matches',
      input: insertMatchSchema,
      responses: {
        201: z.custom<typeof matches.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    history: {
      method: 'GET' as const,
      path: '/api/matches/history',
      responses: {
        200: z.array(z.custom<typeof matches.$inferSelect>()),
      },
    },
  },
};

// ============================================
// TYPE HELPERS
// ============================================
export type FighterResponse = z.infer<typeof api.fighters.get.responses[200]>;
export type MatchInput = z.infer<typeof api.matches.create.input>;
