import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const fighters = pgTable("fighters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  style: text("style").notNull(), // e.g., "Shadow Energy", "Fire Rage"
  avatarUrl: text("avatar_url").notNull(), // Static asset path
  spriteUrl: text("sprite_url").notNull(), // Static asset path for the fighter model
  stats: jsonb("stats").$type<{
    power: number;
    speed: number;
    defense: number;
    health: number;
  }>().notNull(),
  abilities: jsonb("abilities").$type<{
    basic: string;
    special: string;
    awakening: string;
    finisher: string;
  }>().notNull(),
  lore: text("lore").notNull(),
});

export const arenas = pgTable("arenas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  backgroundUrl: text("background_url").notNull(),
  hazard: text("hazard"), // e.g., "Collapsing Floor", "Rain"
});

export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  fighter1Id: integer("fighter1_id").notNull(),
  fighter2Id: integer("fighter2_id").notNull(),
  winnerId: integer("winner_id"), // Null if draw
  arenaId: integer("arena_id").notNull(),
  durationSeconds: integer("duration_seconds").notNull(),
  finishedWithAwakening: boolean("finished_with_awakening").default(false),
  timestamp: text("timestamp").notNull(), // ISO string
});

// === BASE SCHEMAS ===
export const insertFighterSchema = createInsertSchema(fighters).omit({ id: true });
export const insertArenaSchema = createInsertSchema(arenas).omit({ id: true });
export const insertMatchSchema = createInsertSchema(matches).omit({ id: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Fighter = typeof fighters.$inferSelect;
export type Arena = typeof arenas.$inferSelect;
export type Match = typeof matches.$inferSelect;

export type InsertMatch = z.infer<typeof insertMatchSchema>;

export type MatchResultRequest = InsertMatch;

export type FightersListResponse = Fighter[];
export type ArenasListResponse = Arena[];
