import { db } from "./db";
import {
  fighters,
  arenas,
  matches,
  type Fighter,
  type Arena,
  type Match,
  type InsertMatch,
} from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  // Fighters
  getFighters(): Promise<Fighter[]>;
  getFighter(id: number): Promise<Fighter | undefined>;

  // Arenas
  getArenas(): Promise<Arena[]>;
  getArena(id: number): Promise<Arena | undefined>;

  // Matches
  createMatch(match: InsertMatch): Promise<Match>;
  getRecentMatches(): Promise<Match[]>;

  // Seeding
  seedFighters(): Promise<void>;
  seedArenas(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Fighters
  async getFighters(): Promise<Fighter[]> {
    return await db.select().from(fighters);
  }

  async getFighter(id: number): Promise<Fighter | undefined> {
    const [fighter] = await db.select().from(fighters).where({ id } as any); // Type assertion needed for simple where object in some versions or use eq
    // Using simple where object for now, if it fails I'll switch to eq(fighters.id, id)
    // Actually, let's use the proper 'eq' import to be safe in the next step, but for now I'll stick to standard select.
    // Re-writing with query builder pattern which is safer:
    return await db.query.fighters.findFirst({
      where: (fighters, { eq }) => eq(fighters.id, id),
    });
  }

  // Arenas
  async getArenas(): Promise<Arena[]> {
    return await db.select().from(arenas);
  }

  async getArena(id: number): Promise<Arena | undefined> {
    return await db.query.arenas.findFirst({
      where: (arenas, { eq }) => eq(arenas.id, id),
    });
  }

  // Matches
  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const [match] = await db.insert(matches).values(insertMatch).returning();
    return match;
  }

  async getRecentMatches(): Promise<Match[]> {
    return await db
      .select()
      .from(matches)
      .orderBy(desc(matches.timestamp))
      .limit(10);
  }

  // Seeding
  async seedFighters(): Promise<void> {
    const count = await db.select().from(fighters);
    if (count.length > 0) return;

    await db.insert(fighters).values([
      {
        name: "Kael, the Shadow Monk",
        description: "A monk exiled from his order for practicing forbidden shadow arts. He seeks redemption through combat.",
        style: "Shadow Arts",
        avatarUrl: "https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?q=80&w=2069&auto=format&fit=crop", // Placeholder
        spriteUrl: "shadow_monk", // Frontend will handle this ID map to shapes/colors
        stats: { power: 6, speed: 9, defense: 4, health: 100 },
        abilities: {
          basic: "Quick Palm",
          special: "Shadow Step (Teleport behind)",
          awakening: "Void Form (Invisibility dashes)",
          finisher: "Eternal Darkness",
        },
        lore: "Kael swore an oath of silence until he restores his temple's honor.",
      },
      {
        name: "Ignis, the Fallen Samurai",
        description: "A samurai whose blade burns with the souls of those he failed to protect.",
        style: "Inferno Blade",
        avatarUrl: "https://images.unsplash.com/photo-1614726365723-49cfae965252?q=80&w=1974&auto=format&fit=crop", // Placeholder
        spriteUrl: "fire_samurai",
        stats: { power: 9, speed: 5, defense: 7, health: 110 },
        abilities: {
          basic: "Heavy Slash",
          special: "Flame Wave (Projectile)",
          awakening: "Inferno Blade (Attacks burn)",
          finisher: "Soul Incineration",
        },
        lore: "Every swing of his sword brings him closer to consuming his own soul.",
      },
      {
        name: "Lyra, the Beast Tamer",
        description: "Raised by wolves in the northern tundra, she fights with feral instinct.",
        style: "Feral Instinct",
        avatarUrl: "https://images.unsplash.com/photo-1535581652167-3d6b98c36cd9?q=80&w=2070&auto=format&fit=crop", // Placeholder
        spriteUrl: "beast_tamer",
        stats: { power: 7, speed: 8, defense: 5, health: 105 },
        abilities: {
          basic: "Claw Strike",
          special: "Spirit Wolf (Summon helper)",
          awakening: "Pack Leader (Double attack speed)",
          finisher: "The Great Hunt",
        },
        lore: "She fights to protect the last sanctuary of her kin.",
      },
      {
        name: "Vane, the Time Breaker",
        description: "A scientist trapped between seconds, using unstable tech to manipulate time.",
        style: "Chrono Tech",
        avatarUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop", // Placeholder
        spriteUrl: "time_breaker",
        stats: { power: 5, speed: 7, defense: 6, health: 95 },
        abilities: {
          basic: "Phase Punch",
          special: "Rewind (Heal recent damage)",
          awakening: "Chrono Stasis (Slow enemy)",
          finisher: "Timeline Collapse",
        },
        lore: "He searches for the moment everything went wrong, hoping to change it.",
      },
    ]);
  }

  async seedArenas(): Promise<void> {
    const count = await db.select().from(arenas);
    if (count.length > 0) return;

    await db.insert(arenas).values([
      {
        name: "The Crumbling Temple",
        description: "An ancient place of worship, now falling into the abyss.",
        backgroundUrl: "https://images.unsplash.com/photo-1605806616949-1e87b487bc2a?q=80&w=1974&auto=format&fit=crop",
        hazard: "Falling Debris",
      },
      {
        name: "Neon Slums",
        description: "A rain-soaked street in a dystopian mega-city.",
        backgroundUrl: "https://images.unsplash.com/photo-1555680202-c86f0e12f086?q=80&w=2070&auto=format&fit=crop",
        hazard: "Acid Rain",
      },
      {
        name: "Ancient Ruins",
        description: "The remains of a forgotten civilization.",
        backgroundUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1968&auto=format&fit=crop",
        hazard: "None",
      },
    ]);
  }
}

export const storage = new DatabaseStorage();
