import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // === SEED DATA ===
  await storage.seedFighters();
  await storage.seedArenas();

  // === FIGHTERS ===
  app.get(api.fighters.list.path, async (req, res) => {
    const fighters = await storage.getFighters();
    res.json(fighters);
  });

  app.get(api.fighters.get.path, async (req, res) => {
    const fighter = await storage.getFighter(Number(req.params.id));
    if (!fighter) {
      return res.status(404).json({ message: "Fighter not found" });
    }
    res.json(fighter);
  });

  // === ARENAS ===
  app.get(api.arenas.list.path, async (req, res) => {
    const arenas = await storage.getArenas();
    res.json(arenas);
  });

  // === MATCHES ===
  app.post(api.matches.create.path, async (req, res) => {
    try {
      const input = api.matches.create.input.parse(req.body);
      const match = await storage.createMatch(input);
      res.status(201).json(match);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        });
      }
      throw err;
    }
  });

  app.get(api.matches.history.path, async (req, res) => {
    const matches = await storage.getRecentMatches();
    res.json(matches);
  });

  return httpServer;
}
